@echo off
chcp 65001 >nul
echo ================================================
echo         简译AI翻译软件 - 一键启动脚本
echo ================================================
echo.

echo [1/2] 启动后端服务...
start "简译AI - 后端服务" cmd /k "cd /d f:\简译 && python backend/app.py"

timeout /t 3 /nobreak >nul

echo [2/2] 启动前端服务...
start "简译AI - 前端服务" cmd /k "cd /d f:\简译\frontend && python -m http.server 8000"

timeout /t 2 /nobreak >nul

echo.
echo ================================================
echo         服务启动完成！
echo ================================================
echo.
echo 后端服务: http://localhost:5000
echo 前端页面: http://localhost:8000
echo.
echo 按任意键退出...
pause >nul