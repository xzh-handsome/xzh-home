const API_BASE_URL = 'http://localhost:5000/api';

let translationHistory = [];

async function initLanguages() {
    try {
        const response = await fetch(`${API_BASE_URL}/languages`);
        const languages = await response.json();
        
        const sourceLang = document.getElementById('sourceLang');
        const targetLang = document.getElementById('targetLang');
        
        languages.forEach(lang => {
            const option1 = document.createElement('option');
            option1.value = lang.code;
            option1.textContent = lang.name;
            sourceLang.appendChild(option1);
            
            const option2 = document.createElement('option');
            option2.value = lang.code;
            option2.textContent = lang.name;
            targetLang.appendChild(option2);
        });
        
        targetLang.value = 'zh';
    } catch (error) {
        console.error('Failed to load languages:', error);
    }
}

async function translate() {
    const inputText = document.getElementById('inputText').value.trim();
    const sourceLang = document.getElementById('sourceLang').value;
    const targetLang = document.getElementById('targetLang').value;
    
    if (!inputText) {
        showToast('请输入要翻译的文本', 'error');
        return;
    }
    
    showLoading(true);
    
    try {
        const response = await fetch(`${API_BASE_URL}/translate`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                text: inputText,
                from: sourceLang,
                to: targetLang
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            displayTranslation(result.translatedText, result.note);
            saveToHistory(inputText, result.translatedText, sourceLang, targetLang);
            showToast('翻译成功', 'success');
        } else {
            showToast(result.error || '翻译失败', 'error');
        }
    } catch (error) {
        console.error('Translation error:', error);
        showToast('翻译失败，请检查网络连接', 'error');
    } finally {
        showLoading(false);
    }
}

function displayTranslation(text, note = '') {
    const outputText = document.getElementById('outputText');
    if (note) {
        outputText.innerHTML = `<span style="color: #667eea; font-size: 12px; margin-bottom: 8px; display: block;">${note}</span>${text}`;
    } else {
        outputText.textContent = text;
    }
    outputText.classList.remove('empty');
}

function saveToHistory(original, translated, from, to) {
    const item = {
        id: Date.now(),
        original,
        translated,
        from,
        to,
        timestamp: new Date().toLocaleString('zh-CN')
    };
    
    translationHistory.unshift(item);
    
    if (translationHistory.length > 50) {
        translationHistory.pop();
    }
    
    localStorage.setItem('translationHistory', JSON.stringify(translationHistory));
}

function loadHistory() {
    const stored = localStorage.getItem('translationHistory');
    if (stored) {
        translationHistory = JSON.parse(stored);
    }
}

function showHistory() {
    const modal = document.getElementById('historyModal');
    const historyList = document.getElementById('historyList');
    
    if (translationHistory.length === 0) {
        historyList.innerHTML = '<p class="empty-state">暂无翻译记录</p>';
        modal.classList.add('show');
        return;
    }
    
    historyList.innerHTML = translationHistory.map(item => `
        <div class="history-item">
            <div class="original">${escapeHtml(item.original)}</div>
            <div class="translated">${escapeHtml(item.translated)}</div>
            <div style="font-size: 12px; color: #999; margin-top: 8px;">${item.timestamp}</div>
        </div>
    `).join('');
    
    modal.classList.add('show');
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

async function aiEnhance(type) {
    const inputText = document.getElementById('inputText').value.trim();
    
    if (!inputText) {
        showToast('请先输入文本', 'error');
        return;
    }
    
    showLoading(true);
    
    try {
        const response = await fetch(`${API_BASE_URL}/ai-enhance`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                text: inputText,
                type: type
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            displayTranslation(result.enhancedText, result.note);
            showToast('AI增强处理成功', 'success');
        } else {
            showToast(result.error || '处理失败', 'error');
        }
    } catch (error) {
        console.error('AI enhance error:', error);
        showToast('处理失败，请检查网络连接', 'error');
    } finally {
        showLoading(false);
    }
}

function swapLanguages() {
    const sourceLang = document.getElementById('sourceLang');
    const targetLang = document.getElementById('targetLang');
    
    const temp = sourceLang.value;
    sourceLang.value = targetLang.value;
    targetLang.value = temp;
}

function clearInput() {
    document.getElementById('inputText').value = '';
    document.getElementById('outputText').textContent = '';
    document.getElementById('outputText').classList.add('empty');
}

async function copyToClipboard() {
    const outputText = document.getElementById('outputText').textContent;
    
    if (!outputText) {
        showToast('没有可复制的内容', 'error');
        return;
    }
    
    try {
        await navigator.clipboard.writeText(outputText);
        showToast('已复制到剪贴板', 'success');
    } catch (error) {
        console.error('Copy error:', error);
        showToast('复制失败', 'error');
    }
}

function speakText() {
    const outputText = document.getElementById('outputText').textContent;
    
    if (!outputText) {
        showToast('没有可播放的内容', 'error');
        return;
    }
    
    if ('speechSynthesis' in window) {
        speechSynthesis.cancel();
        
        const utterance = new SpeechSynthesisUtterance(outputText);
        utterance.lang = document.getElementById('targetLang').value;
        utterance.rate = 0.9;
        
        speechSynthesis.speak(utterance);
    } else {
        showToast('您的浏览器不支持语音播放', 'error');
    }
}

function showLoading(show) {
    const overlay = document.getElementById('loadingOverlay');
    if (show) {
        overlay.classList.add('show');
    } else {
        overlay.classList.remove('show');
    }
}

function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => toast.classList.add('show'), 10);
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

function initEventListeners() {
    document.getElementById('inputText').addEventListener('input', function() {
        if (this.value.trim()) {
            translate();
        }
    });
    
    document.getElementById('swapBtn').addEventListener('click', swapLanguages);
    document.getElementById('clearBtn').addEventListener('click', clearInput);
    document.getElementById('copyBtn').addEventListener('click', copyToClipboard);
    document.getElementById('voiceOutputBtn').addEventListener('click', speakText);
    document.getElementById('historyBtn').addEventListener('click', showHistory);
    document.getElementById('closeHistoryModal').addEventListener('click', () => {
        document.getElementById('historyModal').classList.remove('show');
    });
    
    document.querySelectorAll('.enhance-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            aiEnhance(this.dataset.type);
        });
    });
    
    document.getElementById('historyModal').addEventListener('click', function(e) {
        if (e.target === this) {
            this.classList.remove('show');
        }
    });
}

document.addEventListener('DOMContentLoaded', () => {
    loadHistory();
    initLanguages();
    initEventListeners();
});