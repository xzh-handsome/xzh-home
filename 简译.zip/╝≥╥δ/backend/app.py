from flask import Flask, request, jsonify
from flask_cors import CORS
import requests
import json

app = Flask(__name__)
CORS(app)

DOUBAO_API_KEY = "ark-10caa772-73ef-4763-98dd-748c2d18ab7e-1faf1"
DOUBAO_API_URL = "https://api.doubao.com/v1/chat/completions"

def translate_with_doubao(text, from_lang, to_lang):
    try:
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {DOUBAO_API_KEY}'
        }
        
        payload = {
            "model": "Doubao-Seed-2.0-Code",
            "messages": [
                {
                    "role": "user",
                    "content": f"请将以下文本从{from_lang}翻译成{to_lang}：\n\n{text}"
                }
            ],
            "max_tokens": 2048,
            "temperature": 0.7
        }
        
        response = requests.post(DOUBAO_API_URL, headers=headers, json=payload, timeout=30)
        response.raise_for_status()
        
        result = response.json()
        
        if 'choices' in result and len(result['choices']) > 0:
            translated_text = result['choices'][0]['message']['content'].strip()
            return {'success': True, 'text': translated_text}
        else:
            return {'success': False, 'error': '翻译结果解析失败'}
            
    except requests.exceptions.RequestException as e:
        return {'success': False, 'error': str(e)}

def mock_translate(text, from_lang, to_lang):
    translations = {
        'hello': {'zh': '你好', 'en': 'hello', 'ja': 'こんにちは', 'ko': '안녕하세요'},
        'world': {'zh': '世界', 'en': 'world', 'ja': '世界', 'ko': '세계'},
        'thank you': {'zh': '谢谢', 'en': 'thank you', 'ja': 'ありがとう', 'ko': '감사합니다'},
        'goodbye': {'zh': '再见', 'en': 'goodbye', 'ja': 'さようなら', 'ko': '안녕히 가세요'},
        'welcome': {'zh': '欢迎', 'en': 'welcome', 'ja': 'ようこそ', 'ko': '환영합니다'}
    }
    
    text_lower = text.lower().strip()
    
    if text_lower in translations:
        if to_lang in translations[text_lower]:
            return translations[text_lower][to_lang]
        else:
            return f"[模拟翻译] {text} -> {to_lang}"
    else:
        return f"[模拟翻译] 从{from_lang}到{to_lang}: {text}"

@app.route('/api/translate', methods=['POST'])
def translate():
    try:
        data = request.get_json()
        text = data.get('text', '')
        from_lang = data.get('from', 'auto')
        to_lang = data.get('to', 'zh')
        
        if not text:
            return jsonify({'error': '请输入要翻译的文本'}), 400
        
        result = translate_with_doubao(text, from_lang, to_lang)
        
        if result['success']:
            return jsonify({
                'success': True,
                'translatedText': result['text'],
                'from': from_lang,
                'to': to_lang
            })
        else:
            app.logger.warning(f"API调用失败，使用模拟模式: {result['error']}")
            return jsonify({
                'success': True,
                'translatedText': mock_translate(text, from_lang, to_lang),
                'from': from_lang,
                'to': to_lang,
                'note': '当前使用模拟模式'
            })
            
    except Exception as e:
        app.logger.error(f"翻译异常: {str(e)}")
        return jsonify({
            'success': True,
            'translatedText': mock_translate(text, from_lang, to_lang),
            'from': from_lang,
            'to': to_lang,
            'note': '当前使用模拟模式'
        })

@app.route('/api/languages', methods=['GET'])
def get_languages():
    languages = [
        {'code': 'auto', 'name': '自动检测'},
        {'code': 'zh', 'name': '中文'},
        {'code': 'en', 'name': '英语'},
        {'code': 'ja', 'name': '日语'},
        {'code': 'ko', 'name': '韩语'},
        {'code': 'fr', 'name': '法语'},
        {'code': 'de', 'name': '德语'},
        {'code': 'es', 'name': '西班牙语'},
        {'code': 'ru', 'name': '俄语'},
        {'code': 'pt', 'name': '葡萄牙语'},
        {'code': 'ar', 'name': '阿拉伯语'},
        {'code': 'hi', 'name': '印地语'}
    ]
    return jsonify(languages)

def ai_enhance_with_doubao(text, enhance_type):
    try:
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {DOUBAO_API_KEY}'
        }
        
        type_descriptions = {
            'polish': '润色优化',
            'expand': '扩写',
            'shorten': '精简',
            'formal': '转为正式风格',
            'casual': '转为口语风格',
            'academic': '转为学术风格'
        }
        
        prompt = f"请对以下文本进行{type_descriptions.get(enhance_type, '润色优化')}：\n\n{text}"
        
        payload = {
            "model": "Doubao-Seed-2.0-Code",
            "messages": [
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "max_tokens": 2048,
            "temperature": 0.7
        }
        
        response = requests.post(DOUBAO_API_URL, headers=headers, json=payload, timeout=30)
        response.raise_for_status()
        
        result = response.json()
        
        if 'choices' in result and len(result['choices']) > 0:
            enhanced_text = result['choices'][0]['message']['content'].strip()
            return {'success': True, 'text': enhanced_text}
        else:
            return {'success': False, 'error': '处理结果解析失败'}
            
    except requests.exceptions.RequestException as e:
        return {'success': False, 'error': str(e)}

def mock_ai_enhance(text, enhance_type):
    type_descriptions = {
        'polish': '润色优化',
        'expand': '扩写',
        'shorten': '精简',
        'formal': '转为正式风格',
        'casual': '转为口语风格',
        'academic': '转为学术风格'
    }
    return f"[AI{type_descriptions.get(enhance_type)}] {text}"

@app.route('/api/ai-enhance', methods=['POST'])
def ai_enhance():
    try:
        data = request.get_json()
        text = data.get('text', '')
        enhance_type = data.get('type', 'polish')
        
        if not text:
            return jsonify({'error': '请输入文本'}), 400
        
        result = ai_enhance_with_doubao(text, enhance_type)
        
        if result['success']:
            return jsonify({
                'success': True,
                'enhancedText': result['text'],
                'type': enhance_type
            })
        else:
            app.logger.warning(f"AI增强API调用失败，使用模拟模式: {result['error']}")
            return jsonify({
                'success': True,
                'enhancedText': mock_ai_enhance(text, enhance_type),
                'type': enhance_type,
                'note': '当前使用模拟模式'
            })
            
    except Exception as e:
        app.logger.error(f"AI增强异常: {str(e)}")
        return jsonify({
            'success': True,
            'enhancedText': mock_ai_enhance(text, enhance_type),
            'type': enhance_type,
            'note': '当前使用模拟模式'
        })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)